//Kendisine parametre olarak gelen bir ba�l� do�rusal listeden yine kendisine parametre olarak gelen integer veriye sahip nodelar� silen,
// sildi�i node say�s�n� �a�r�ld��� yere g�nderen nodesil()
#include <iostream>
#include <conio.h>
#include <time.h>
#include<stdlib.h>
#include<locale.h>
using namespace std;
struct node
{
	int data;
	node* link;
};
node* cuthead(node*& list)
{
	node* cuthead=list;
	if(list!=NULL)
	{
		list=list->link;
		cuthead->link=NULL;
	}
	return(cuthead);
}
node* nodesil(int data_, node* list)
{
	int i=0;
	node* temp=list;
	node* locate=NULL;
if(list == NULL) {// liste bo� olabilir.
cout<<"Listede eleman yok\n";
}
else if(list -> link == NULL) // listede tek d���m bulunabilir.
cout<<"Silmek istediginiz veri bulunmamaktadir.\n\n";


if(list->data==data_){//aranan data ilk node'da olabilir.
cuthead(list);
i++;
list=list->link;
}
if(list->data!=data_)//arada ise
{
	list=list->link;	
}
else
{
   i++;
   temp=list;
   list->link=NULL;
   temp->link= temp -> link -> link;
}
cout<<i<<" adet eleman bulunmaktad�r.";
}
int main()
{
	setlocale(LC_ALL,"Turkish");
	node* l1;
	int data1;
	cout<<"Aramak istedi�iniz datay� giriniz: ";
	cin>>data1;
	nodesil(data1, l1);
}

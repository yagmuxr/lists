node* cuthead(node*& list) 

{ 

node* cuthead(node*& list) 

{ 

node* ylist=list; 

node* cuthead=list; 

if(list!=NULL) 

{ 

list=list->link; 

cuthead->link=NULL; 

do 

{ 

ylist=list->link; 

}while(list!=ylist); 

link=ylist; 

 

} 

return(cuthead); 

} 

}  

//Kendisine parametre olarak gelen bir ba�l� do�rusal listeyi node say�s� �ift ise ikiye ay�ran ve listeleri �a�r�ld��� yere g�nderen ayir()
#include <iostream>
#include <conio.h>
#include <time.h>
#include<stdlib.h>
#include<locale.h>
using namespace std;
struct node
{
	int data;
	node* link;
};
node* ayir(node* list){
	int i=0;
	node* temp=NULL;
	while(list!=NULL)
	{
		cout<<"Listenin "<<i++<<". nodunun adresi: "<<list<<endl;
		cout<<"datas�: "<<list->data<<endl;
		cout<<"linki: "<<list->link;n
		list=list->link;
		i++;
	}
	if(i%2==0)
	{
		int z=i/2;
		for(int j=0; j<z; j++)
		{
			list=list->link;
		}
		temp=list->link;
		list->link=NULL;
		
	}
	//1. liste list ad�nda ikinci liste temp ad�nda art�k
}


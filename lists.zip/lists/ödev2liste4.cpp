#include <iostream> 

#include <conio.h> 

#include <time.h> 

#include<stdlib.h> 

#include<locale.h> 

using namespace std; 

struct node 

{ 

	int data; 

	node* link; 

}; 

node* newnode() 

{ 

	node* newnode=new node; 

	newnode->link=newnode; 

	return(newnode); 

	} 

node* last(node* list) 

{ 

	if(list!=NULL) 

	{ 

		node* ylist=list; 

		while(list->link!=NULL) 

	    list=list->link; 

   } 

	node* last=list; 

	return(last); 

	}	 

void concatenate(node*& l1, node* l2) 

{ 

	if(l1==NULL) l1=l2; 

	else 

	last(l1)->link=l2; 

	last(l2)->link=l1; 

	} 

  

node* cons(int data_) 

{ 

	node* cons_; 

	cons_=newnode(); 

	cons_->data=data_; 

	return(cons_); 

	} 

node* kopyala(node* list, int data_){ 

	node* locate=NULL; 

	node* suret=NULL; 

	node* ylist=list; 

	if(list!=NULL) 

	{ 

		node* ylist=list; 

		do{ 

			if(list->data<data_)list=list->link; 

			else if(list->data>=data_) 

			{ 

				do{ 

					concatenate(suret,cons(list->data)); 

					list=list->link; 

				}while(list!=ylist); 

			} 

		}while(list!=ylist); 

	} 

} 

int main() 

{ 

	node* list1; 

	int data1; 

	cout<<"Data giriniz: "; 

	cin>>data1; 

	kopyala(list1, data1); 

	 

} 
